class Main {
  public static void main(String[] args) {
    A a;
    a = new A();
    /* INLINE */ a.printVal();
  }
}

class A {
  int x;

  public int printVal() {
    System.out.println(this.x);
    return this.x;
  }
}
