class TC1 {
  public static void main(String[] a) { System.out.println(8); }
}
