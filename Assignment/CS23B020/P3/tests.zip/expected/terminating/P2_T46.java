class T146 {
  public static void main(String[] args) { System.out.println(2); }
}
