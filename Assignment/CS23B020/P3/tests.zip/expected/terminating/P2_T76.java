class T257 {
  public static void main(String[] args) { System.out.println(1); }
}
