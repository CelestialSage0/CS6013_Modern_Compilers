class t17 {
  public static void main(String[] args) { System.out.println(0); }
}
